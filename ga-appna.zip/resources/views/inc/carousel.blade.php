<div id="carousel-example" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example" data-slide-to="1"></li>
    <li data-target="#carousel-example" data-slide-to="2"></li>
    <li data-target="#carousel-example" data-slide-to="3"></li>
    <li data-target="#carousel-example" data-slide-to="4"></li>
    <li data-target="#carousel-example" data-slide-to="5"></li>
    <li data-target="#carousel-example" data-slide-to="6"></li>
    <li data-target="#carousel-example" data-slide-to="7"></li>
  </ol>

  <div class="carousel-inner">
    <div class="item active">
      <a href="#"><img src="/img/firstmeeting.jpg" /></a>
      <div class="carousel-caption">
        <h3>APPNA GA Fashion Show 2017</h3>
        <p></p>
      </div>
    </div>
    <!-- <div class="item">
      <a href="#"><img src="/img/fs10.jpg" /></a>
      <div class="carousel-caption">
        <h3>APPNA GA Fashion Show 2017</h3>
        <p></p>
      </div>
    </div> -->
    <div class="item">
      <a href="#"><img src="/img/fs 6.jpg" /></a>
      <div class="carousel-caption">
        <h3>APPNA GA Fashion Show 2017</h3>
        <p></p>
      </div>
    </div>
    <div class="item">
      <a href="#"><img src="/img/fs 5.jpg" /></a>
      <div class="carousel-caption">
        <h3>APPNA GA Fashion Show 2017</h3>
        <p></p>
      </div>
    </div>

    <div class="item">
      <a href="#"><img src="/img/fash sh 3.jpg" /></a>
      <div class="carousel-caption">
        <h3>APPNA GA Fashion Show 2017</h3>
        <p></p>
      </div>
    </div>

    <div class="item">
      <a href="#"><img src="/img/fs16.jpg" /></a>
      <div class="carousel-caption">
        <h3>APPNA GA Fashion Show 2017</h3>
        <p></p>
      </div>
    </div>

    <div class="item">
      <a href="#"><img src="/img/fs19.jpg" /></a>
      <div class="carousel-caption">
        <h3>APPNA GA Fashion Show 2017</h3>
        <p></p>
      </div>
    </div>

    <div class="item">
      <a href="#"><img src="/img/fs 5.jpg" /></a>
      <div class="carousel-caption">
        <h3>APPNA GA Fashion Show 2017</h3>
        <p></p>
      </div>
    </div>
  </div>

  <a class="left carousel-control" href="#carousel-example" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
  </a>
  <a class="right carousel-control" href="#carousel-example" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
