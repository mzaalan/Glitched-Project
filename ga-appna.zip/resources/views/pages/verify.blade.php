<div class="container">
    <h1>Please verify your email.</h1>
</div>