@extends('layouts.app')
@section('content')
<div class="container">
    {{--  <iframe src="   " style="width:100%;" frameborder="0">
        alternative content for browsers which do not support iframe.</iframe>  --}}
        <a data-flickr-embed="true"  href="https://www.flickr.com/photos/158116364@N05/albums/72157663743646048" title="APPNA GA Fashion Show"><img src="https://farm5.staticflickr.com/4589/38232832315_bfe200bdd8_o.jpg" style="width:100%; height:100%" alt="APPNA GA Fashion Show"></a><script async src="//embedr.flickr.com/assets/client-code.js" charset="utf-8"></script>
</div>
@endsection