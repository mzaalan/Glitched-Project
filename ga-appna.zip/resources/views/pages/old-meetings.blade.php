@extends('layouts.app')
@section('content')
    <div class="container">
        <div class="col-md-10">
            <h4 style="color: #0A1572"><strong><u>First GA APPNA Business Meeting: Saturday, March 11th, 2017</u></strong></h4>
            <img src="http://img1.10bestmedia.com/Images/Photos/32627/the-oceanaire-seafood-room-miami-fl-usa-restaurants-search-all-restaurants-1544248_54_990x660_201405311530.jpg" class="pull-right img-responsive" height="100px" width="300px">

            <p style="color: #0A1572"><u><strong>Venue :</strong></u><strong><u>The Oceanaire Seafood Room<br /></p><p></u>1100 Peachtree Street<br />Atlanta, GA 30309<br /></strong></p>
            <p>Date and Time: March 11, 2017 at 12pm (noon)</p>
            <p>Speaker:&nbsp;<strong>David G. Robertson, MD</strong></p>
            
            <p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>
            <p><u><strong>Agenda :</strong></u></p>
            <p>Welcome : Dr. Asher Niazi&nbsp;/ Introduction of new cabinet<br />12:05 : Speaker<br />12:30 : Treasurer Report<br />12:35 &nbsp;: Committees announcement<br />12:50 : Overview of Programs during 2017</p>
            <p>1:00 PM : Discuss By&nbsp;Laws / Election Process : Thoughts and&nbsp;discussion<br />1:15 : Platform open to members for any suggestions.</p>
            <p>&nbsp; &nbsp; &nbsp;&nbsp;</p>
            <p>&nbsp;</p>

            <p><h4 style="text-decoration: underline; color: #0A1572"><strong>Ga-Appna's Second business meeting is scheduled for August the 13th</strong><strong>&nbsp;&nbsp;at Canoe restaurant at Noon</strong></h4><br /><span style="text-decoration: underline;"><strong>Agenda :</strong></span><br />Welcome : Dr. Asher Niazi&nbsp;<br />12:05 : Speaker-Dr Yaseen Abubaker<br />12:30 : Treasurer Report<br />12:35 : Overview of Programs during 2017<br />12:40&nbsp; : Discuss By&nbsp;Laws / Election Process : Thoughts and&nbsp;discussion<br />1250: questions</p>
        </div>
    </div>
@endsection